/*CREATE TABLE product
(product_id number(5),
product_name varchar2(32),
supplier_name varchar2(32),
unit_price number(7,2) );

begin
insert into product values(1,'Ahmed','Toshiba','1000');
insert into product values(2,'Ali','LG','2000');
insert into product values(3,'Sara','SONY','500');
end;*/

select * from product;
